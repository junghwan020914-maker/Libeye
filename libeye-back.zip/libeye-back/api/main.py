from fastapi import FastAPI, Depends, HTTPException, Path
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from pydantic import BaseModel
import uuid
from typing import List, Optional, Any

# 직접 작성한 내부 모듈 임포트
from database import get_db, engine, Base
import models
from storage import get_presigned_upload_url, get_presigned_download_url
from worker import process_scan_image

# (선택) 앱 시작 시 DB 테이블 자동 생성 - 01-init.sql을 쓰므로 생략 가능하나 안전장치로 추가
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="LibEye API Server",
    description="스마트 서고 관리 시스템 - DB 및 Message Queue 연동 완료",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- [Pydantic DTO 모델 정의] ---
class SessionCreateRequest(BaseModel):
    location_id: str
    user_id: str

class SessionCreateResponse(BaseModel):
    session_id: str
    status: str
    
class UploadUrlResponse(BaseModel):
    upload_url: str
    expires_in: int

# --- [API 라우터] ---

@app.get("/")
def root():
    return {"message": "LibEye API 서버가 정상적으로 실행 중입니다. (DB/Redis 연동 완료)"}

@app.post("/api/v1/sessions", response_model=SessionCreateResponse, status_code=201)
def create_session(request: SessionCreateRequest, db: Session = Depends(get_db)):
    """
    1. 스캔 세션 생성: PostgreSQL DB에 새로운 스캔 세션 레코드를 INSERT 합니다.
    """
    new_session_id = uuid.uuid4()
    object_name = f"sessions/{new_session_id}/original.jpg" # MinIO에 저장될 경로
    
    # ORM을 통한 데이터베이스 INSERT
    new_session = models.ScanSession(
        session_id=new_session_id,
        location_id=request.location_id,
        user_id=request.user_id,
        image_url=object_name,
        overall_status="CREATED" # 초기 상태
    )
    
    try:
        db.add(new_session)
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"DB 저장 실패: {str(e)}")
        
    return SessionCreateResponse(
        session_id=str(new_session_id),
        status="CREATED"
    )

@app.get("/api/v1/sessions/{session_id}/upload-url", response_model=UploadUrlResponse)
def generate_upload_url(session_id: str = Path(...), db: Session = Depends(get_db)):
    """
    2. MinIO Presigned URL 발급
    """
    # 세션 존재 여부 확인
    session = db.query(models.ScanSession).filter(models.ScanSession.session_id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="세션을 찾을 수 없습니다.")
        
    try:
        upload_url = get_presigned_upload_url("original-bucket", session.image_url)
        return UploadUrlResponse(upload_url=upload_url, expires_in=300)
    except Exception as e:
        raise HTTPException(status_code=500, detail="업로드 URL 생성 실패")

@app.post("/api/v1/sessions/{session_id}/analyze")
def start_analysis(session_id: str, db: Session = Depends(get_db)):
    """
    3. 분석 시작 (클라이언트가 사진 업로드를 완료한 후 호출):
    Celery Queue에 AI 분석 작업을 밀어넣고(비동기), DB 상태를 업데이트합니다.
    """
    session = db.query(models.ScanSession).filter(models.ScanSession.session_id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="세션을 찾을 수 없습니다.")
    
    # 상태 업데이트
    session.overall_status = "PROCESSING"
    db.commit()
    
    # Celery 워커로 비동기 작업 던지기 (.delay를 사용하면 백그라운드로 실행됨)
    process_scan_image.delay(
        session_id=str(session.session_id),
        location_id=session.location_id,
        image_object_name=session.image_url
    )
    
    return {"message": "AI 분석이 큐에 등록되었습니다.", "status": "PROCESSING"}

@app.get("/api/v1/sessions/{session_id}/status")
def get_session_status(session_id: str, db: Session = Depends(get_db)):
    """
    4. 분석 상태 폴링: DB에서 현재 상태를 읽어 반환합니다.
    """
    session = db.query(models.ScanSession).filter(models.ScanSession.session_id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="세션을 찾을 수 없습니다.")
        
    return {
        "session_id": session_id,
        "status": session.overall_status
    }

@app.get("/api/v1/sessions/{session_id}/results")
def get_session_results(session_id: str, db: Session = Depends(get_db)):
    """
    5. 분석 결과 반환: Scan_Result_Detail 테이블에서 매칭 결과를 조회하여 반환합니다.
    """
    session = db.query(models.ScanSession).filter(models.ScanSession.session_id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="세션을 찾을 수 없습니다.")
        
    # 프론트엔드 이미지 표시용 URL (임시 다운로드 링크)
    image_url = get_presigned_download_url("original-bucket", session.image_url)
    
    # 1:N 관계로 묶인 상세 인식 결과(details) 조회
    details = session.details 
    
    detections = []
    for d in details:
        detections.append({
            "detection_id": str(d.detection_id),
            "bounding_box": d.bounding_box,
            "ocr_text": d.ocr_text,
            "matched_book_id": d.matched_book_id,
            "status": d.status
        })
        
    return {
        "session_id": session_id,
        "image_url": image_url,
        "overall_status": session.overall_status,
        "detections": detections
    }
